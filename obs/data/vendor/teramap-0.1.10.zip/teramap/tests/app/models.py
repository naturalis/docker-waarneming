from django.contrib.gis.db.models import GeometryField
from django.db import models


class Location(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(null=True)
    geom = GeometryField()


class Observation(models.Model):
    description = models.TextField(null=True)
    geom = GeometryField()
    date = models.DateField(null=True)
