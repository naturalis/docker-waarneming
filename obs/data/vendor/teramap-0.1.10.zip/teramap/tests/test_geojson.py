from datetime import datetime

from django.test import TestCase
from model_mommy import mommy

import teramap
from teramap.geojson import FeatureCollection, LineString, Point, TransformToPoint

from .app.models import Location, Observation


class FeatureCollectionTest(TestCase):
    def test_union(self):
        a = FeatureCollection([
            LineString([[41, 37], [40, 62], [34, 62]]),
            Point([4, 52])
        ])

        b = FeatureCollection([
            Point([6, 52])
        ])

        c = a.union(b)

        self.assertEquals(len(a), 2)
        self.assertEquals(len(b), 1)
        self.assertEquals(len(c), 3)

    def test_union_with_or_operation(self):
        a = FeatureCollection([
            Point([1, 2]),
            Point([3, 4])
        ])
        b = FeatureCollection([
            Point([1, 6]),
            LineString([[2, 8], [4, 9], [9, 3]])
        ])
        c = FeatureCollection([
            Point([1, 5]),
            Point([2, 4])
        ])

        d = a + b + c

        def get_coords(obj):
            return [
                feature.to_geojson()['geometry']['coordinates']
                for feature in obj.features
            ]

        self.assertEquals(len(d), 6)
        self.assertEquals(get_coords(d), [
            [1, 2],
            [3, 4],
            [1, 6],
            [[2, 8], [4, 9], [9, 3]],
            [1, 5],
            [2, 4]
        ])

        e = c + b + a
        self.assertEquals(len(e), 6)
        self.assertEquals(get_coords(e), [
            [1, 5],
            [2, 4],
            [1, 6],
            [[2, 8], [4, 9], [9, 3]],
            [1, 2],
            [3, 4],

        ])


class GeoJSONTest(TestCase):
    def setUp(self):
        mommy.make(Location, name='puntje', geom='POINT(4 2)', description='foo')
        mommy.make(Observation, geom='POINT(4 2)', description='foo', date=datetime.now())

    def test_extra_properties(self):
        class GeoJSON(teramap.GeoJSON):
            properties = {
                'name': 'name'
            }

        geojson = GeoJSON(Location.objects.all(), extra_properties={'description': 'description'})

        data = geojson.to_geojson()

        self.assertEquals(data['features'][0]['properties'], {
            'name': 'puntje',
            'description': 'foo'
        })

    def test_callable_properties(self):
        class GeoJSON(teramap.GeoJSON):
            properties = {
                'name': lambda o: o.name.upper()
            }

        geojson = GeoJSON(Location.objects.all())
        data = geojson.to_geojson()

        self.assertEquals(data['features'][0]['properties'], {
            'name': 'PUNTJE',
        })

    def test_boolean_properties(self):
        '''
        If the lookup of a property is a boolean, just use that boolean.
        '''

        class GeoJSON(teramap.GeoJSON):
            properties = {
                'name': 'name',
                'no_popup': True,
                'tooltip': False,
            }

        geojson = GeoJSON(Location.objects.all())
        data = geojson.to_geojson()

        self.assertEquals(
            set(data['features'][0]['properties'].items()),
            set((('name', 'puntje'), ('no_popup', True), ('tooltip', False)))
        )

    def test_conversion_to_string(self):
        class GeoJSON(teramap.GeoJSON):
            properties = {
                'name': 'name',
            }

        class ObservationGeoJSON(teramap.GeoJSON):
            properties = {
                'name': 'date',

            }

        geojson = ObservationGeoJSON(Observation.objects.all()) + GeoJSON(Location.objects.all())

        self.assertEquals(len(geojson), 2)
        data = geojson.to_geojson_str()

        self.assertEquals(data, str(geojson))
        self.assertIn('puntje', data)

    def test_geom_tansform_centroid(self):
        Location.objects.create(name='polygon 1', geom='POLYGON ((-5 50, 10 50, 10 55, -5 55, -5 50))')
        Location.objects.create(name='polygon 2', geom='POLYGON ((-15 60, 10 60, 10 70, -15 70, -15 60))')
        Location.objects.create(name='line 2', geom='LINESTRING (14 60, -6 56, -14 47, -1 38)')

        class GeoJSON(TransformToPoint, teramap.GeoJSON):
            properties = {
                'name': 'name',
            }

        geojson = GeoJSON(Location.objects.all()).to_geojson()
        for feature in geojson['features']:
            self.assertEquals(feature['geometry']['type'], 'Point')
