from django.test import TestCase

from teramap.utils import attr_or_key, round_geom


class UtilsTest(TestCase):
    def test_attr_or_key(self):
        class Obj(object):
            foo = 'bar'

        o = Obj()
        d = dict(bar='foo')

        self.assertEquals(attr_or_key(o, 'foo'), 'bar')
        self.assertEquals(attr_or_key(d, 'bar'), 'foo')

    def test_round_geom(self):
        self.assertEquals(round_geom([1, 2], 6), [1, 2])
        self.assertEquals(round_geom([[1, 3], [3, 4]], 6), [[1, 3], [3, 4]])

        self.assertEquals(round_geom([1.1122, 1.2233], 2), [1.11, 1.22])
        self.assertEquals(
            round_geom([[1, 2], [1.1122, 1.2233]], 2),
            [[1, 2], [1.11, 1.22]]
        )
