import json

from django.test import TestCase
from django.template import Context, Template

from teramap import __version__

from .app.models import Location


class TemplateTagTest(TestCase):
    def test_teramap_version(self):
        template = Template('{% load teramap %}{% teramap_version %}')

        self.assertEquals(template.render(Context({})), __version__)
