import L from 'leaflet';

// we assume the resulting teramap.js is consumed using the bundle
// with leaflet loaded externally.
// can be replaced with externals options if this is merged:
// https://github.com/webpack-contrib/css-loader/pull/496
// import 'leaflet/dist/leaflet.css';

// make sure Leaflet's images work properly:
// delete L.Icon.Default.prototype._getIconUrl;
// L.Icon.Default.mergeOptions({
//     iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
//     iconUrl: require('leaflet/dist/images/marker-icon.png'),
//     shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
// });


import 'leaflet-fullscreen';
import 'leaflet-fullscreen/dist/leaflet.fullscreen.css';

import preventAccidentalScroll from './lib/leaflet-scroll-intent.js';

function leaflet_map(map_id, options) {
    options = L.extend({
        fullscreen: true,
        preventAccidentalScroll: true,
        callback: L.Util.falseFn,
        baseLayer: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            'minZoom': 3,
            'maxZoom': 19,
            'attribution': '&copy; OpenStreetMap',
        }),
        overlays: {},
        center: [51, 4],
        zoom: 6
    }, options || {});

    var map = L.map(map_id).setView(options.center, options.zoom);
    map.addLayer(options.baseLayer);

    if (Object.keys(options.overlayer).length > 0) {
        L.control.layers({}, options.overlays).addTo(map);
    }

    if (options.fullscreenControl) {
        L.control.fullscreen().addTo(map);
    }
    if (options.preventAccidentalScroll) {
        preventAccidentalScroll(map);
    }
    if (typeof options.callback == 'function') {
        options.callback(map);
    }

    return map;
}

export default leaflet_map;
