var numberMarker = require('../lib/leaflet-number-marker.js');

function Pinpoint(pinpoint_data) {
    /*
     * Input arg `pinpoint_data`, object containing keys:
     *  - `protocol`
     *  - `initial_data`
     *  - `messages` (dict of translations with english as keys.)
     *
     * Example for protocol key:
     *  {
     *     pinpoint_target: 'observation' or 'sample'
     *     species: {2: {name: "Stag Beetle", is_primary: true}, 4: {name: ...}},
     *     subjects: {4: "adult male", 7: "adult female"}},
     *     sample_attrs: {
     *         4: {name: 'Wind (Bft)'},
     *         5: {name: 'schaduw', choices: ['geen', '30%', '60%', '100%']
     *     }
     *  }
     *
     * `initial_data`: list of pins containing:
     *   - a name, pk (if updating)
     *   - observations, containing a list of observations.
     *
     * For example:
     * [
     *     // in case of pinpoint sample:
     *     {
     *         pk: 42,
     *         name: 1,
     *         latlng: [54, 2],
     *         attributes: {11: 'value', 12: '6'},
     *         observations: [
     *            {species: 2, subject: 2, count: 3, [pk: 4]},
     *            {species: 2, subject: 3, count: 1, [pk: 4]},
     *            ...
     *     },
     *     // in case of pinpoint observation, the sample is just a dummy
     *     // (containing only it's pk while editing)
     *     {
     *         pk: 43,
     *         observations: [
     *            {species: 2, subject: 2, count: 3, [pk: 4], latlng: [52, 2], name: 1},
     *            {species: 2, subject: 2, count: 3, [pk: 4], latlng: [52, 3], name: 2},

     *         ]
     *     }
     * ]
     * This is also the serialisation format used save the data.
     */
    var protocol = this.protocol = pinpoint_data.protocol;

    this.pinpoint_observation = protocol.pinpoint_target == 'observation';
    var pinpoint_observation = this.pinpoint_observation;
    this.subjects = protocol.subjects;
    this.species = protocol.species;

    this.samples = pinpoint_data.initial_data || [];
    // add dummy sample
    if (pinpoint_observation && this.samples.length === 0) {
        this.samples.push({observations: []});
    }

    // mark species active if one of the pins has an observation containing it.
    this.samples.forEach(function (sample) {
        sample.observations.forEach(function (observation) {
            if (observation.species) {
                protocol.species[observation.species].is_active = true;
            }
        });
    });

    var active_species = [];
    (function () {
        var arr = [];
        var species = protocol.species;
        for (var i in species) {
            if (species[i].is_primary || species[i].is_active) {
                arr.push(species[i]);
            }
        }
        // sort initially on is_primary, name:
        arr.sort(function (a, b) {
            if (a.is_primary && !b.is_primary) { return -1; }
            if (b.is_primary && !a.is_primary) { return 1; }
            return a.name > b.name;
        });
        arr.forEach(function (species) {
            active_species.push(species.pk);
        });
    })();

    this.eachSubject = function (fn) {
        for (var pk in this.subjects) {
            fn(this.subjects[pk], pk);
        }
    };

    this.eachSpecies = function (callback, filter, context) {
        for (var i in this.species) {
            if (filter && !filter(this.species[i])) {
                continue;
            }
            callback.call(context, this.species[i]);
        }
    };

    this.eachActiveSpecies = function (callback, context) {
        active_species.forEach(function (species_pk) {
            callback.call(context, this.species[species_pk]);
        }, this);
    };

    // all species, except those active
    this.eachSelectableSpecies = function (callback, context) {
        this.eachSpecies(callback, function (species) {
            return !(species.is_primary || species.is_active);
        }, context);
    };

    this.update_attribute = function (pin_name, attr_pk, value) {
        var sample = this.get_sample(pin_name);
        sample.attributes[attr_pk] = value;
    };

    this.activate_species = function (species_pk) {
        this.species[species_pk].is_active = true;
        active_species.push(species_pk);
    };

    this.get_sample = function (pin_name) {
        if (pinpoint_observation) {
            return this.samples[0];
        } else {
            var ret;
            this.samples.forEach(function (sample) {
                if (sample.name == pin_name) {
                    ret = sample;
                }
            });
            return ret;
        }
    };

    this.get_observation = function (pin_name, species_pk, subject_pk) {
        var observation;

        var sample = this.get_sample(pin_name);
        sample.observations.forEach(function (obs) {
            if (pinpoint_observation) {
                if (obs.name === pin_name) {
                    observation = obs;
                }
            } else {
                var equals = obs.species == species_pk && obs.subject == subject_pk;
                if (sample.name == pin_name && equals) {
                    observation = obs;
                }
            }
        });

        return observation;
    };

    this.remove_observation = function (pin_name, species_pk, subject_pk) {
        var sample = this.get_sample(pin_name);
        var observation = this.get_observation(pin_name, species_pk, subject_pk);

        var index = sample.observations.indexOf(observation);
        sample.observations.splice(index, 1);
    };

    this.update_count = function (pin_name, species_pk, subject_pk, count) {
        // coerce to number if not undefined.
        if (count !== undefined && count !== '') {
            count = +count;
        }
        var species = this.species[species_pk];

        var sample = this.get_sample(pin_name);
        var observation = this.get_observation(pin_name, species_pk, subject_pk);

        // do not save 0-counts for non-primary species and no undefined counts
        // at all
        if ((!species.is_primary && count === undefined) || count === '') {
            if (observation) {
                this.remove_observation(pin_name, species_pk, subject_pk);
            }
            return;
        }

        if (observation) {
            L.extend(observation, {
                species: species_pk,
                subject: subject_pk,
                count: count
            });
        } else if (!pinpoint_observation) {
            sample.observations.push({
                species: species_pk,
                subject: subject_pk,
                count: count
            });
        }
    };

    this.observed_count = function (pin_name, species_pk, subject_pk) {
        var observation = this.get_observation(pin_name, species_pk, subject_pk);

        return observation ? observation.count : undefined;
    };

    // return the maxiumum pin name currently used + 1
    this.next_pin_name = function () {
        var pin_name = 0;
        this.samples.forEach(function (sample) {
            if (pinpoint_observation) {
                sample.observations.forEach(function (obs) {
                    pin_name = Math.max(pin_name, +obs.name);
                });
            } else {
                pin_name = Math.max(pin_name, +sample.name);
            }
        });

        return '' + (pin_name + 1);
    };

    function convertLatLng(latlng) {
        latlng = L.latLng(latlng);
        return [latlng.lat, latlng.lng];
    }

    // Create a new empty pin at latlng, initializing the list of observations.
    this.createPin = function (latlng) {
        var pin = {
            name: this.next_pin_name(),
            latlng: convertLatLng(latlng)
        };

        if (pinpoint_observation) {
            var sample = this.get_sample();
            sample.observations.push(pin);
        } else {
            L.extend(pin, {
                observations: [],
                attributes: {}
            });
            this.samples.push(pin);
        }

        return this.createMarker(pin);
    };

    this.createMarker = function (observation) {
        var pin = numberMarker(observation.latlng, observation.name);
        pin.feature = {properties: observation};
        return pin;
    };

    this.setLatLng = function (pin_name, latlng) {
        this.getPin(pin_name).latlng = convertLatLng(latlng);
    };

    this.getPin = function (pin_name) {
        if (pinpoint_observation) {
            return this.get_observation(pin_name);
        } else {
            return this.get_sample(pin_name);
        }
    };

    this.eachPin = function (fn) {
        var list = pinpoint_observation ? this.samples[0].observations : this.samples;

        for (var i in list) {
            fn(list[i], i);
        }
    };

    this.hasObservations = function (pin_name) {
        var pin = this.getPin(pin_name);
        if (pin === undefined) {
            return false;
        }
        if (pinpoint_observation) {
            return 'species' in pin;
        } else {
            return pin.observations.length > 0;
        }
    };

    this.removePin = function (pin_name) {
        var list;
        if (pinpoint_observation) {
            var sample = this.get_sample();
            list = sample.observations;
        } else {
            list = this.samples;
        }
        for (var i in list) {
            if (list[i].name == pin_name) {
                list.splice(i, 1);
            }
        }
    };

    // Gather the data for the table below the map.
    this.table_data = function () {
        var ret = [];
        var header = [_('location'), _('species')];
        if (pinpoint_observation) {
            header.push(_('subject'), _('count'));
        } else {
            this.eachSubject(function (name) {
                header.push(name);
            });
        }
        ret.push(header);
        var self = this;
        this.samples.forEach(function (sample) {
            if (sample.observations.length < 1) {
                return;
            }
            if (pinpoint_observation) {
                sample.observations.forEach(function (obs) {
                    var species = self.species[obs.species];
                    var subject = self.subjects[obs.subject];
                    ret.push([obs.name, species, subject, obs.count]);
                });
            } else {
                self.eachActiveSpecies(function (species) {
                    var row = [sample.name, species];
                    var has_nonzero_observation = false;
                    self.eachSubject(function (name, subject_pk) {
                        var count = self.observed_count(sample.name, species.pk, subject_pk);

                        if (count !== 0) {
                            has_nonzero_observation = true;
                        }
                        row.push(count);
                    });
                    if (species.is_primary || has_nonzero_observation) {
                        ret.push(row);
                    }
                });
            }
        });

        return ret;
    };

    this.serialize = function () {
        return JSON.stringify(this.samples, null, 2);
    };

    this._ = function (key, ucfirst) {
        var value = pinpoint_data.messages[key] || key;

        if (ucfirst) {
            return value.charAt(0).toUpperCase() + value.substring(1);
        } else {
            return value;
        }
    };
    var _ = this._;
}

export default Pinpoint;
