function Renderer (form_data) {
    var _ = form_data._;

    function form_group(contents) {
        return '<div class="form-group">' + contents + '</div>';
    }

    function render_species_name (species, extra_classes) {
        var classNames = extra_classes || '';
        if (species.is_primary) {
            classNames += ' app-transect-species-primary';
        }

        return L.Util.template('<span class="{class}">{name}</span>', {
            class: classNames,
            name: species.name
        });
    }

    // render the table.
    this.table = function (selector) {
        var edit_fmt = '<div class="leaflet-number-marker">{name}</div>&nbsp;&nbsp;' +
            '<span data-pin-name="{name}" class="btn-group btn-group-xs">' +
                '<span data-target="edit" class="btn btn-default"><i class="fa fa-edit"></i></span>' +
                '<span data-target="move-marker" class="btn btn-default"><i class="fa fa-map-marker"></i></span>' +
                '<span data-target="delete" class="btn btn-danger"><i class="fa fa-remove"></i></span>' +
            '</span>';

        var html = '<thead><tr>';
        var data = form_data.table_data();
        data[0].forEach(function (header) {
            html += '<th>' + header + '</th>';
        });
        html += '</tr>';

        var prev_name;
        data.slice(1).forEach(function (row) {
            var name = row[0];
            if (prev_name === undefined || prev_name != name) {
                html += '<tr class="first"><td>' + L.Util.template(edit_fmt, {
                    name: name
                });
            } else {
                html += '<tr><td>';
            }
            html += '</td>';
            html += '<td>' + render_species_name(row[1]) + '</td>';

            row.slice(2).forEach(function (column) {
                column = (column === undefined) ? '' : column;
                html += '<td>' + column + '</td>';
            });
            prev_name = name;
        });
        html += '</tbody>';

        selector.html(html);
    };

    // renders an input, (type=number by default)
    function render_input(attributes) {
        attributes = L.extend({type: 'number'}, attributes);

        var attrs = [];
        for (var name in attributes) {
            attrs.push(name + '="' + attributes[name] + '"');
        }

        return '<input ' + attrs.join(' ') + '/>';
    }

    // Render an input row for a species.
    function render_input_row(pin_name, species) {
        var row = '<tr><td>' + render_species_name(species, 'form-control-static text-right') + '</td>';

        form_data.eachSubject(function (name, subject_pk) {
            var input = render_input({
                class: 'form-control app-transect-subject-input center-block',
                'data-species': species.pk,
                'data-subject': subject_pk,
                'value': form_data.observed_count(pin_name, species.pk, subject_pk) || ''
            });
            row += '<td>' + input + '</td>';
        });
        row += '</tr>';
        return row;
    }

    function render_secondary_selector() {
        var subject_count = 0;
        form_data.eachSubject(function () { subject_count++; });

        var html = '<tr>' +
            '<td><select class="form-control species-selector"></select></td>' +
            '<td colspan="' + subject_count + '">' +
            '<span class="btn btn-success" data-add="secondary">' + _('add') + '</span>' +
            '</td>' +
            '</tr>';

        return html;
    }
    function species_to_select2_dict(arr) {
        return function (item) {
            arr.push({id: item.pk, text: item.name, is_primary: item.is_primary});
        };
    }

    function get_selectable_species() {
        var species = [];
        if (form_data.pinpoint_observation) {
            form_data.eachActiveSpecies(species_to_select2_dict(species));
        }

        form_data.eachSelectableSpecies(species_to_select2_dict(species));
        return species;
    }

    this.modal = function(selector, pin_name) {
        var selectable_species = get_selectable_species();
        var pin = form_data.getPin(pin_name);

        selector.data('name', pin_name);
        selector.find('.pinpoint-name').html('<div class="leaflet-number-marker">' + pin_name + '</div>');

        var html = '';
        // Sample attributes.
        var sample_attrs = form_data.protocol.sample_attrs;
        if (!form_data.pinpoint_observation && sample_attrs && Object.keys(sample_attrs).length > 0) {
            html += '<h4>' + _('attributes', true) + '</h4>';
            for (var pk in sample_attrs) {
                var attr = sample_attrs[pk];

                var input = '<label class="control-label col-sm-4">' + attr.name + '</label>';
                input += '<div class="col-sm-6">';

                var current_value = pin.attributes[pk] || '';
                if (attr.choices && attr.choices.length > 0) {
                    input += '<select data-sample-attr="' + pk + '" class="form-control">';
                    attr.choices.forEach(function (choice) {
                        var selected = (choice[0] == current_value) ? 'selected="selected"' : '';
                        input += '<option value="' + choice[0] + '" ' + selected + '>' + choice[1] + '</option>';
                    });
                    input += '</select>';
                } else {
                    input += render_input({
                        type: 'text',
                        class: 'form-control',
                        'data-sample-attr': pk,
                        value: current_value
                    });
                }
                input += '</div>';
                html += form_group(input);
            }
        }

        if (form_data.pinpoint_observation) {
            // let the user choose species, subjects and supply a count.
            html += '<div class="form-group">' +
                form_group('<select class="form-control species-selector"></select>') +
                form_group('<select class="form-control subject-selector"></select>') +
                form_group(render_input({
                    class: 'form-control',
                    name: 'count',
                    placeholder: 'count'
                })) + '</div>';
        } else {
            html += '<table class="table app-transect-table">';
            html += '<tr><th>' + _('species') + '</th>';
            form_data.eachSubject(function (name) {
                html += '<td>' + name + '</td>';
            });
            html += '</tr>';

            form_data.eachActiveSpecies(function (species) {
                html += render_input_row(pin_name, species);
            });

            if (selectable_species.length > 0) {
                html += render_secondary_selector();
            }
            html += '</table>';
        }

        selector.find('form').html('<div class="modal-body">' + html + '</div>');

        if (selectable_species.length > 0) {
            selector.find('.species-selector').select2({
                escapeMarkup: function (a) { return a; },
                templateResult: function (data) {
                    if ('is_primary' in data && data.is_primary) {
                        return '<span class="app-transect-species-primary">' + data.text + '</span>';
                    }
                    return data.text;
                },
                data: selectable_species
            });
        }
        if (form_data.pinpoint_observation) {
            var subjects = [];
            form_data.eachSubject(function (name, pk) {
                subjects.push({id: pk, text: name});
            });

            selector.find('.subject-selector').select2({
                data: subjects
            });

            // set the initial values for this form:
            var observation = form_data.get_observation(pin_name);
            if (observation && observation.species && observation.subject) {
                selector.find('.species-selector').val(observation.species).trigger('change');
                selector.find('.subject-selector').val(observation.subject).trigger('change');
                selector.find('[name="count"]').val(observation.count);
            }
        }
        selector.find('form')
            .toggleClass('form-inline', form_data.pinpoint_observation)
            .toggleClass('form-horizontal', !form_data.pinpoint_observation);
    };
}

export default Renderer;
