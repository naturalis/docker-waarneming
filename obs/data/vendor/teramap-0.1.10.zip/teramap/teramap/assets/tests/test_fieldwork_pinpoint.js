
var i18n_messages = {
    'attributes': 'attributes',
    'add': 'add',
    'location': 'location',
    'species': 'species'
};
var species = {
    '192': {pk: 192, is_primary: true, name: 'Beekoeverlibel'},
    '209': {pk: 209, is_primary: true, name: 'Huiskrekel'},
    '205': {pk: 205, is_primary: false, name: 'Bandheidelibel'},
    '206': {pk: 206, is_primary: false, name: 'Bloedrode heidelibel'}
};
var subjects = {
    '24': 'adult man',
    '25': 'adult vrouw'
};
var sample_attrs = {
    '32': {name: 'criteria occupation', choices: []},
    '9': {name: 'shading', choices: [['unknown', 'unknown'], ['no shade', 'no shade'], ['<30%', '<30%'], ['30-60%', '30-60%'], ['>60%', '>60%']]},
    '3': {name: 'wind-force (bft)', choices: []},
    '37': {name: 'accessibility', choices: []}
};

var protocol_sample = function () {
    // make sure to clone
    return L.extend({}, {
        name: 'Instippen (sample)',
        pinpoint_target: 'sample',
        species: species,
        subjects: subjects,
        sample_attrs: sample_attrs
    });
};
var protocol_observation = {
    name: 'Instippen (observation)',
    pinpoint_target: 'observation',
    species: species,
    subjects: subjects,
    sample_attrs: {},
};


describe('Pinpoint', function () {
    chai.should();

    function compareTable(actual, expected) {
        actual.forEach(function (row, i) {
            row[0].should.deep.equal(expected[i][0]);
            if (i == 0) {
                row[1].should.deep.equal(expected[i][1]);
            } else {
                row[1].name.should.deep.equal(expected[i][1].name);
            }
            if (row[2] === undefined) {
                (expected[i][2] === undefined).should.be.true;
            }
            if (row[3] === undefined) {
                (expected[i][3] === undefined).should.be.true;
            }
        });
    }

    describe('pinpoint observation', function () {
        describe('without initial data', function () {
            var form_data = new teramap.fieldwork.Pinpoint({
                protocol: protocol_observation,
                initial_data: [],
                messages: i18n_messages
            });

            it('has the correct pinpoint_observation property', function () {
                form_data.pinpoint_observation.should.be.true;
            });

            it('adds the dummy sample', function () {
                var data = new teramap.fieldwork.Pinpoint({
                    protocol: protocol_observation,
                    initial_data: [],
                    messages: i18n_messages
                });

                data.samples[0].should.have.key('observations');
            });
            it('returns correct subjects', function () {
                var actual_subjects = {};
                form_data.eachSubject(function (s, pk) {
                    actual_subjects[pk] = s;
                });

                actual_subjects.should.deep.equal(subjects);
            });

            it('returns correct species', function () {
                var actual_species = {};
                form_data.eachSpecies(function (s) {
                    actual_species[s.pk] = s;
                });
                actual_species.should.deep.equal(species);
            });

            it('correctly record and update observations', function () {
                var pin = form_data.createPin([51, 2]);
                var pin_name = pin.feature.properties.name;

                var species_pk = Object.keys(species)[0];
                var subject_pk = Object.keys(subjects)[0];

                form_data.update_count(pin_name, species_pk, subject_pk, 3);
                form_data.observed_count(pin_name, species_pk, subject_pk).should.equal(3);

                form_data.update_count(pin_name, species_pk, subject_pk, 10);
                form_data.observed_count(pin_name, species_pk, subject_pk).should.equal(10);

                form_data.update_count(pin_name, species_pk, subject_pk, 3);
                form_data.observed_count(pin_name, species_pk, subject_pk).should.equal(3);
            });

            it('returns the right table structure.', function () {
                var data = form_data.table_data();
                var expected = [
                    ['location', 'species', 'subject', 'count'],
                    ['1', species[192], 'adult man', 3]
                ];
                data.should.deep.equal(expected);
            });

            it('should remove an observation if a pin is removed', function () {
                var pin = form_data.createPin([51, 2]);
                var pin_name = pin.feature.properties.name;

                form_data.getPin(pin_name).name.should.equal(pin_name);

                // remove the pin
                form_data.removePin(pin_name);

                (form_data.getPin(pin_name) === undefined).should.be.true;

                form_data.samples[0].observations.length.should.equal(1);
            });

            it('should allow moving the location of a pin', function () {
                var pin = form_data.createPin([51, 2]);
                var pin_name = pin.feature.properties.name;

                form_data.getPin(pin_name).latlng.should.deep.equal([51, 2]);

                form_data.setLatLng(pin_name, [33, 1]);
                form_data.getPin(pin_name).latlng.should.deep.equal([33, 1]);
            });

            it('should correctly iterate each species', function () {
                var obj = {};
                form_data.eachSpecies(function (species) {
                    obj[species.pk] = species;
                });
                var expected = L.extend({}, species);
                expected[205].is_active = true;

                obj.should.deep.equal(expected);
            });
        });


        describe('Using initial data', function () {
            it('correctly marks secondary species active if they are in in initial_data', function () {
                var initial_data = [{
                    pk: 111,
                    observations: [
                        {'pk': 34, species: 205, subject: 24, count: 23},
                        {'pk': 35, species: 205, subject: 25, count: 2},
                    ]
                }];
                var data = new teramap.fieldwork.Pinpoint({
                    protocol: protocol_observation,
                    initial_data: initial_data,
                    messages: i18n_messages
                });

                data.species[205].is_active.should.be.true;
            });
        });
    });

    describe('pinpoint sample', function () {
        it('has the correct pinpoint_observation property', function () {
            var form_data = new teramap.fieldwork.Pinpoint({
                protocol: protocol_sample(),
                initial_data: [],
                messages: i18n_messages
            });
            form_data.pinpoint_observation.should.be.false;
        });

        it('correctly records observations', function () {
            var form_data = new teramap.fieldwork.Pinpoint({
                protocol: protocol_sample(),
                initial_data: [],
                messages: i18n_messages
            });
            var pin = form_data.createPin([51, 2]);
            var pin_name = pin.feature.properties.name;
            var species_pk = Object.keys(species)[0];
            form_data.eachSubject(function (name, subject_pk) {
                form_data.update_count(pin_name, species_pk, subject_pk, 3);
                form_data.observed_count(pin_name, species_pk, subject_pk).should.equal(3);
            });

            compareTable(form_data.table_data(), [
                ['location', 'species', 'adult man', 'adult vrouw'],
                ['1', species[192], 3, 3],
                ['1', species[209], undefined, undefined],
                ['1', species[205], undefined, undefined]
            ]);

            form_data.eachSubject(function (name, subject_pk) {
                form_data.update_count(pin_name, 209, subject_pk, 6);
            });

            compareTable(form_data.table_data(), [
                ['location', 'species', 'adult man', 'adult vrouw'],
                ['1', species[192], 3, 3],
                ['1', species[209], 6, 6],
                ['1', species[205], undefined, undefined]
            ]);
        });

        it('should add a sample when a pin is added', function () {
            var form_data = new teramap.fieldwork.Pinpoint({
                protocol: protocol_sample(),
                initial_data: [],
                messages: {}
            });
            form_data.createPin([41, 4]);
            form_data.createPin([33, 3]);

            form_data.samples.length.should.equal(2);
        });

        it('should not report 0-observations for secondary species', function () {
            var form_data = new teramap.fieldwork.Pinpoint({
                protocol: protocol_sample(),
                initial_data: [],
                messages: {}
            });

            var pin = form_data.createPin([22, 33]);
            var pin_name = pin.feature.properties.name;
            var sample = form_data.get_sample(pin_name);

            var primary_pk = 192;
            var secondary_pk = 205;
            var secondary_pk2 = 206;

            // first 'form row', primary species, explicit non-zero count
            form_data.update_count(pin_name, primary_pk, 25, 3);
            // this should not result in a 0-observation but will be
            // created as a 0-observation server-side.
            form_data.update_count(pin_name, primary_pk, 24, '');

            // second 'form row', secondary species
            form_data.update_count(pin_name, secondary_pk, 25, 3);
            // this should not result in an observation
            form_data.update_count(pin_name, secondary_pk, 24, '');

            // third 'form row', another secondary species, should both not result
            // in an observation.
            form_data.update_count(pin_name, secondary_pk2, 25, '');
            form_data.update_count(pin_name, secondary_pk2, 25, '');

            sample.observations.length.should.equal(2);

            // explicit 0-observation for primary species should result in a 0-observation
            form_data.update_count(pin_name, primary_pk, 24, 0);
            sample.observations.length.should.equal(3);

            // explicit 0-observations for secondary species should result in a 0-observation
            form_data.update_count(pin_name, secondary_pk2, 24, 0);
            sample.observations.length.should.equal(4);

        });
    });
});
