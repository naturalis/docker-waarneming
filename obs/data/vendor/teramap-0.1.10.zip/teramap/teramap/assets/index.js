import map_with_geojson from './leaflet-geojson-map.js';
import Pinpoint from './fieldwork/pinpoint.js';
import Renderer from './fieldwork/pinpoint-renderer.js';

window.teramap = map_with_geojson;
window.teramap.fieldwork = {
    Pinpoint: Pinpoint,
    PinpoointRenderer: Renderer
};
