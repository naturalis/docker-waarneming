import L from 'leaflet';

import leaflet_map from './leaflet-map.js';

import './lib/leaflet-number-marker.js';
import './lib/leaflet-number-marker.css';

function layer_bounds(layer) {
    if (layer.getBounds) {
        return layer.getBounds();
    } else {
        return L.latLngBounds(layer.getLatLng(), layer.getLatLng());
    }
}

function map_with_geojson(map_id, options, geojson) {
    var map = leaflet_map(map_id, options);

    if (geojson) {
        var layer = L.geoJson(geojson, {
            style: function(feature) {
                var style = {};
                if ('color' in feature.properties) {
                    style['color'] = feature.properties.color;
                }
                return style;
            },
            onEachFeature: function (feature, layer) {
                var properties = feature.properties;
                if ('no_popup' in properties) {
                    return;
                }
                // set the icon to a number icon if properties contains a number_marker property.
                if ('number_marker' in properties) {
                    layer.setIcon(L.numberIcon(properties.number_marker));
                }
                if ('name' in properties || 'projects' in properties) {
                    var html = '';
                    if ('projects' in properties && properties.projects.length > 0) {
                        html += '<strong>Projecten</strong>';
                        html += '<ul>';
                        properties.projects.forEach(function (project) {
                            html += L.Util.template('<li><a href="{url}">{name}</a></li>', project);
                        });
                        html += '</ul>';
                    } else {
                        if ('url' in properties) {
                            html = L.Util.template('<a href="{url}">{name}</a>', properties);
                        } else {
                            html = properties.name;
                        }
                    }
                    html += '<br />';
                    if ('location_id' in properties) {
                        var focus_on_fmt = '<a href="javascript:focusOnFeature(\'location_id\', {location_id})">&gt; laat zien op de kaart</a>';
                        html += L.Util.template(focus_on_fmt, properties);
                    }
                    layer.bindPopup(html);
                }
            }
        }).addTo(map);
        // TODO: use bindPopup here to defer creating the popup.

        window.zoomOut = function () {
            var bounds = layer.getBounds();
            if (bounds.isValid()) {
                map.fitBounds(bounds, {maxZoom: 16});
            }
        };
        window.zoomOut();

        window.focusOnFeature = function (key, value) {
            layer.eachLayer(function (layer) {
                var properties = layer.feature.properties;
                if (key in properties && properties[key] == value) {
                    map.fitBounds(layer_bounds(layer), {maxZoom: 16});
                }
            });
        };

        window.geojson_layer = layer;
    }
    map.invalidateSize();
    return map;
}

window.map_with_geojson = map_with_geojson;
export default map_with_geojson;
