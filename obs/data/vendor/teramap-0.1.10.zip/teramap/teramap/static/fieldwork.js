
import Pinpoint from './fieldwork/pinpoint.js';
import PinpointController from './fieldwork/pinpoint-controller.js';
import {PinpointTable, PinpointRenderer} from './fieldwork/pinpoint-renderer.js';
import {is_primary, Protocol} from './fieldwork/protocol.js';

import './fieldwork/fieldwork.css';

var fieldwork = {
    Protocol,
    PinpointController,
    Pinpoint,
    PinpointRenderer,
    PinpointTable,
    is_primary
};

export {
    fieldwork
};
