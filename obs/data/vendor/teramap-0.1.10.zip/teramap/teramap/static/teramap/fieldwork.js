var teramap =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 28);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = L;

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.numberMarker = exports.numberIcon = exports.NumberIcon = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; /*
                                                                                                                                                                                                                                                                               * Small round marker containing a number.
                                                                                                                                                                                                                                                                               */

var _leaflet = __webpack_require__(0);

var _leaflet2 = _interopRequireDefault(_leaflet);

__webpack_require__(3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NumberIcon = _leaflet2.default.NumberIcon = _leaflet2.default.DivIcon.extend({
    options: {
        html: '',
        shadowUrl: null,
        iconSize: new _leaflet2.default.Point(20, 20),

        className: 'leaflet-number-marker'
    }
});

var numberIcon = _leaflet2.default.numberIcon = function (number) {
    var options = (typeof number === 'undefined' ? 'undefined' : _typeof(number)) == 'object' ? number : { html: number };
    return new _leaflet2.default.NumberIcon(options);
};

var numberMarker = _leaflet2.default.numberMarker = function (latlng, number) {
    return _leaflet2.default.marker(latlng, {
        icon: _leaflet2.default.numberIcon(number)
    });
};

exports.NumberIcon = NumberIcon;
exports.numberIcon = numberIcon;
exports.numberMarker = numberMarker;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function is_primary(species) {
    return 'is_primary' in species ? species.is_primary : false;
}

function _active_species(protocol) {
    var active = [];
    var species = protocol.species;
    for (var i in species) {
        if (is_primary(species[i]) || species[i].is_active) {
            active.push(species[i]);
        }
    }
    // sort initially on is_primary, name:
    active.sort(function (a, b) {
        if (is_primary(a) && !is_primary(b)) {
            return -1;
        }
        if (is_primary(b) && !is_primary(a)) {
            return 1;
        }
        return a.name > b.name;
    });

    return active.map(function (species) {
        return species.pk;
    });
}

var Protocol = function () {
    /* Class to manage the a protocol.
     * Refer to ./README.md for documentation
     */
    function Protocol(protocol) {
        _classCallCheck(this, Protocol);

        ['subjects', 'species', 'groups'].forEach(function (type) {
            if (Object.keys(protocol[type]).length === 0) {
                throw new Error('No ' + type + ' provided');
            }
        });

        this.subjects = protocol.subjects;
        this.species = protocol.species;
        this.groups = protocol.groups;

        this.pinpoint_target = protocol.pinpoint_target;
        this.pinpoint_observation = protocol.pinpoint_target == 'observation';

        this.sample_attrs = protocol.sample_attrs || {};

        this.active_species = _active_species(protocol);
    }

    _createClass(Protocol, [{
        key: 'activateSpecies',
        value: function activateSpecies(species_pk) {
            this.species[species_pk].is_active = true;
            if (this.active_species.indexOf(species_pk) === -1) {
                this.active_species.push(species_pk);
            }
        }
    }, {
        key: 'eachSubject',
        value: function eachSubject(fn, group_pk) {
            var subjects;
            if (group_pk !== undefined) {
                subjects = this.groups[group_pk].subjects;
            } else {
                subjects = Object.keys(this.subjects);
            }
            subjects.forEach(function (pk) {
                fn(this.subjects[pk], pk);
            }, this);
        }

        // iterate over subjects by unique name.

    }, {
        key: 'eachSubjectName',
        value: function eachSubjectName(fn) {
            var subjects = {};
            this.eachSubject(function (subject, pk) {
                if (!(subject in subjects)) {
                    subjects[subject] = [];
                }
                subjects[subject].push(+pk);
            });

            for (var name in subjects) {
                fn(name, subjects[name]);
            }
        }
    }, {
        key: '_eachSpecies',
        value: function _eachSpecies(callback, filter, context) {
            // low level eachSpecies, which takes custom filter method.
            for (var i in this.species) {
                if (filter && !filter(this.species[i])) {
                    continue;
                }
                callback.call(context, this.species[i], this.species[i].pk);
            }
        }
    }, {
        key: 'eachActiveSpecies',
        value: function eachActiveSpecies(callback, group_pk) {
            var active_species = this.active_species;
            if (group_pk !== undefined) {
                var group_species = this.groups[group_pk].species;
                active_species = active_species.filter(function (pk) {
                    return group_species.indexOf(pk) !== -1;
                });
            }

            active_species.forEach(function (species_pk) {
                callback(this.species[species_pk], species_pk);
            }, this);
        }

        // all species, except those active

    }, {
        key: 'eachSelectableSpecies',
        value: function eachSelectableSpecies(callback, group_pk) {
            var group_species = false;
            if (group_pk !== undefined) {
                group_species = this.groups[group_pk].species;
            }

            this._eachSpecies(callback, function (species) {
                if (group_species && group_species.indexOf(species.pk) === -1) {
                    return false;
                }
                return !(is_primary(species) || species.is_active);
            });
        }
    }, {
        key: 'eachGroup',
        value: function eachGroup(fn) {
            for (var pk in this.groups) {
                fn(this.groups[pk], pk);
            }
        }
    }, {
        key: 'getGroupForSpecies',
        value: function getGroupForSpecies(species) {
            // returns the group species belongs to.
            for (var pk in this.groups) {
                var group = this.groups[pk];
                if (group.species.indexOf(species.pk) !== -1) {
                    return group;
                }
            }
        }
    }, {
        key: 'selectSubjectForSpecies',
        value: function selectSubjectForSpecies(subject_pks, species) {
            // from a list of subject pks, get the one relevant for this species.
            var ret;
            var group = this.getGroupForSpecies(species);
            group.subjects.forEach(function (subject) {
                if (subject_pks.indexOf(subject) !== -1) {
                    ret = subject;
                }
            });
            return ret;
        }
    }, {
        key: 'hasSampleAttrs',
        value: function hasSampleAttrs() {
            return !this.pinpoint_observation && Object.keys(this.sample_attrs).length > 0;
        }
    }, {
        key: 'eachSampleAttr',
        value: function eachSampleAttr(fn) {
            for (var pk in this.sample_attrs) {
                fn(this.sample_attrs[pk], pk);
            }
        }
    }]);

    return Protocol;
}();

exports.is_primary = is_primary;
exports.Protocol = Protocol;
exports.default = Protocol;

/***/ }),
/* 3 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _leafletNumberMarker = __webpack_require__(1);

var _protocol = __webpack_require__(2);

function Pinpoint(pinpoint_data) {
    /* Class to manage the data for pinpoint form.
     * Refer to ./README.md for documentation
     */
    var protocol = this.protocol = new _protocol.Protocol(pinpoint_data.protocol);
    var pinpoint_observation = protocol.pinpoint_observation;

    this.samples = pinpoint_data.initial_data || [];

    // add dummy sample when we use pinpoint_observation
    if (pinpoint_observation && this.samples.length === 0) {
        this.samples.push({ observations: [] });
    }

    // mark species active if one of the pins has an observation containing it.
    this.samples.forEach(function (sample) {
        sample.observations.forEach(function (observation) {
            if (observation.species) {
                protocol.activateSpecies(observation.species);
            }
        });
    });

    this.updateAttribute = function (pin_name, attr_pk, value) {
        var sample = this.getSample(pin_name);
        sample.attributes[attr_pk] = value;
    };

    this.getSample = function (pin_name) {
        if (pinpoint_observation) {
            // for pinpoint_sample, all observations are part of the dummy sample.
            return this.samples[0];
        } else {
            var ret;
            this.samples.forEach(function (sample) {
                if (sample.name == pin_name) {
                    ret = sample;
                }
            });
            return ret;
        }
    };

    this.getObservation = function (pin_name, species_pk, subject_pk) {
        var observation;

        var sample = this.getSample(pin_name);
        sample.observations.forEach(function (obs) {
            if (pinpoint_observation) {
                if (obs.name === pin_name) {
                    observation = obs;
                }
            } else {
                var equals = obs.species == species_pk && obs.subject == subject_pk;
                if (sample.name == pin_name && equals) {
                    observation = obs;
                }
            }
        });

        return observation;
    };

    this.removeObservation = function (pin_name, species_pk, subject_pk) {
        var sample = this.getSample(pin_name);
        var observation = this.getObservation(pin_name, species_pk, subject_pk);

        var index = sample.observations.indexOf(observation);
        if (pinpoint_observation) {
            observation.count = undefined;
        } else {
            sample.observations.splice(index, 1);
        }
    };

    this.updateCount = function (pin_name, species_pk, subject_pk, count) {
        // coerce to number if not undefined.
        if (count !== undefined && count !== '') {
            count = Math.abs(+count);
        }
        var species = protocol.species[species_pk];

        var sample = this.getSample(pin_name);
        var observation = this.getObservation(pin_name, species_pk, subject_pk);

        if (observation) {
            L.extend(observation, {
                species: species_pk,
                subject: subject_pk,
                count: count
            });
        }
        // do not save 0-counts for non-primary species and no undefined counts at all
        if (!(0, _protocol.is_primary)(species) && count === undefined || count === '') {
            if (observation) {
                this.removeObservation(pin_name, species_pk, subject_pk);
            }
            return;
        }

        if (!observation && !pinpoint_observation) {
            sample.observations.push({
                species: species_pk,
                subject: subject_pk,
                count: count
            });
        }
    };

    this.observedCount = function (pin_name, species_pk, subject_pk) {
        var observation = this.getObservation(pin_name, species_pk, subject_pk);

        return observation ? observation.count : undefined;
    };

    // return the maxiumum pin name currently used + 1
    this.next_pin_name = function () {
        var pin_name = 0;
        this.samples.forEach(function (sample) {
            if (pinpoint_observation) {
                sample.observations.forEach(function (obs) {
                    pin_name = Math.max(pin_name, +obs.name);
                });
            } else {
                pin_name = Math.max(pin_name, +sample.name);
            }
        });

        return '' + (pin_name + 1);
    };

    function convertLatLng(latlng) {
        latlng = L.latLng(latlng);
        return [latlng.lat, latlng.lng];
    }

    // Create a new empty pin at latlng, initializing the list of observations.
    this.createPin = function (latlng) {
        var pin = {
            name: this.next_pin_name(),
            // identify this new pin to delete is when edit cancelled.
            delete_on_cancel: true
        };

        if (pinpoint_observation) {
            var sample = this.getSample();
            sample.observations.push(pin);
        } else {
            L.extend(pin, {
                observations: [],
                attributes: {}
            });
            this.samples.push(pin);
        }

        if (latlng) {
            pin.latlng = convertLatLng(latlng);
        }
        return pin;
    };

    this.createMarker = function (pin) {
        var marker = (0, _leafletNumberMarker.numberMarker)(pin.latlng, pin.name);
        marker.feature = { properties: pin };
        return marker;
    };

    this.setLatLng = function (pin_name, latlng) {
        this.getPin(pin_name).latlng = convertLatLng(latlng);
    };

    this.getPin = function (pin_name) {
        if (pinpoint_observation) {
            return this.getObservation(pin_name);
        } else {
            return this.getSample(pin_name);
        }
    };

    this.eachPin = function (fn) {
        var list = pinpoint_observation ? this.samples[0].observations : this.samples;

        for (var i in list) {
            fn(list[i], i);
        }
    };

    this.hasObservations = function (pin_name) {
        var pin = this.getPin(pin_name);
        if (pin === undefined) {
            return false;
        }
        if (pinpoint_observation) {
            return 'species' in pin;
        } else {
            return pin.observations.length > 0;
        }
    };

    this.removePin = function (pin_name) {
        var list;
        if (pinpoint_observation) {
            var sample = this.getSample();
            list = sample.observations;
        } else {
            list = this.samples;
        }
        for (var i in list) {
            if (list[i].name == pin_name) {
                list.splice(i, 1);
            }
        }
    };

    // Gather the data for the table below the map.
    this.tableData = function () {
        var ret = [];
        var header = [_('location'), _('species')];
        if (pinpoint_observation) {
            header.push(_('subject'), _('count'));
        } else {
            protocol.eachSubjectName(function (name) {
                header.push(name);
            });
        }
        ret.push(header);
        var self = this;
        this.samples.forEach(function (sample) {
            if (pinpoint_observation) {
                sample.observations.forEach(function (obs) {
                    var species = protocol.species[obs.species];
                    var subject = protocol.subjects[obs.subject];
                    ret.push([obs.name, species, subject, obs.count]);
                });
            } else {
                if (sample.observations.length < 1) {
                    var row = [sample.name, { name: _('no observations') }];
                    // add enough empty columns for the subjects.
                    protocol.eachSubjectName(function () {
                        row.push('');
                    });
                    ret.push(row);
                    return;
                }
                protocol.eachActiveSpecies(function (species) {
                    var counts = [];
                    protocol.eachSubjectName(function (name, subject_pks) {
                        var subject_pk = protocol.selectSubjectForSpecies(subject_pks, species);
                        counts.push(self.observedCount(sample.name, species.pk, subject_pk));
                    });

                    if ((0, _protocol.is_primary)(species) || counts.some(function (c) {
                        return c !== undefined;
                    })) {
                        ret.push([sample.name, species].concat(counts));
                    }
                });
            }
        });

        return ret;
    };

    this.serialize = function () {
        return JSON.stringify(this.samples, null, 2);
    };

    this._ = function (key, ucfirst) {
        var value = key;
        if ('messages' in pinpoint_data) {
            value = pinpoint_data.messages[key] || key;
        }

        if (ucfirst) {
            return value.charAt(0).toUpperCase() + value.substring(1);
        } else {
            return value;
        }
    };
    var _ = this._;
}

exports.default = Pinpoint;

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = extend;
// https://github.com/Leaflet/Leaflet/blob/master/src/core/Util.js

function extend(dest) {
    var i, j, len, src;

    for (j = 1, len = arguments.length; j < len; j++) {
        src = arguments[j];
        for (i in src) {
            dest[i] = src[i];
        }
    }
    return dest;
}

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PinpointRenderer = exports.PinpointTable = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _extend = __webpack_require__(5);

var _extend2 = _interopRequireDefault(_extend);

var _template = __webpack_require__(30);

var _template2 = _interopRequireDefault(_template);

var _protocol = __webpack_require__(2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function render_species_name(species, extra_classes) {
    var classNames = extra_classes || '';
    if ((0, _protocol.is_primary)(species)) {
        classNames += ' app-transect-species-primary';
    }

    return (0, _template2.default)('<span class="{class}" title="{scientific_name}">{name}</span>', {
        class: classNames,
        scientific_name: species.scientific_name || '',
        name: species.name || '<em>' + species.scientific_name + '</em>'
    });
}

function form_group(contents) {
    return '<div class="form-group">' + contents + '</div>';
}

// renders an input, (type=number by default)
function render_input(attributes) {
    attributes = (0, _extend2.default)({ type: 'number' }, attributes);

    var attrs = [];
    for (var name in attributes) {
        attrs.push(name + '="' + attributes[name] + '"');
    }

    return '<input ' + attrs.join(' ') + '/>';
}

var PinpointTable = function () {
    function PinpointTable(form_data, options, selector) {
        _classCallCheck(this, PinpointTable);

        this.form_data = form_data;
        this.options = options;
        this.selector = selector;
    }

    _createClass(PinpointTable, [{
        key: 'render',
        value: function render(data) {
            var options = this.options;

            var edit_fmt = '<div class="leaflet-number-marker">{name}</div>&nbsp;&nbsp;' + '<span data-pin-name="{name}" class="btn-group btn-group-xs">' + '<span data-target="edit" class="btn btn-default"><i class="fa fa-edit"></i></span>' + (options.mapclick_create ? '<span data-target="move-marker" class="btn btn-default"><i class="fa fa-map-marker"></i></span>' : '') + '<span data-target="delete" class="btn btn-danger"><i class="fa fa-remove"></i></span>' + '</span>';

            var html = '<thead><tr>';
            data[0].forEach(function (header) {
                html += '<th>' + header + '</th>';
            });
            html += '</tr>';

            var prev_name;
            data.slice(1).forEach(function (row) {
                var name = row[0];
                if (prev_name === undefined || prev_name != name) {
                    html += '<tr class="first"><td>' + (0, _template2.default)(edit_fmt, {
                        name: name
                    });
                } else {
                    html += '<tr><td>';
                }
                html += '</td>';
                html += '<td>' + render_species_name(row[1]) + '</td>';

                row.slice(2).forEach(function (column) {
                    column = column === undefined ? '' : column;
                    html += '<td>' + column + '</td>';
                });
                prev_name = name;
            });
            html += '</tbody>';

            this.selector.html(html);
        }
    }]);

    return PinpointTable;
}();

function PinpointRenderer(form_data, options) {
    var _ = form_data._;
    var protocol = form_data.protocol;

    // Render an input row for a species.
    function render_input_row(pin_name, species, group) {
        var row = '<tr><td>' + render_species_name(species, 'form-control-static text-right') + '</td>';

        protocol.eachSubject(function (name, subject_pk) {
            var value = form_data.observedCount(pin_name, species.pk, subject_pk);
            if (value === undefined) {
                value = '';
            }

            var input = render_input({
                'class': 'form-control app-transect-subject-input center-block',
                'data-species': species.pk,
                'data-subject': subject_pk,
                'min': 0,
                'value': value
            });
            row += '<td>' + input + '</td>';
        }, group.pk);
        row += '</tr>';
        return row;
    }

    function render_secondary_selector(group) {
        var subject_count = 0;
        protocol.eachSubject(function () {
            subject_count++;
        }, group.pk);

        var html = '<tr>' + '<td><select class="form-control species-selector" data-group="' + group.pk + '"></select></td>' + '<td colspan="' + subject_count + '">' + '</td>' + '</tr>';

        return html;
    }

    function get_selectable_species(group_pk) {
        var species = [];
        function species_to_select2_dict(item) {
            species.push({
                id: item.pk,
                text: item.name || '<em>' + item.scientific_name + '</em>',
                is_primary: (0, _protocol.is_primary)(item),
                group: protocol.getGroupForSpecies(item)
            });
        }

        // in case of pinpoint_observation, also include active species.
        if (protocol.pinpoint_observation) {
            protocol.eachActiveSpecies(species_to_select2_dict, group_pk);
        }

        protocol.eachSelectableSpecies(species_to_select2_dict, group_pk);
        return species;
    }

    function render_species_select2(selector, data) {
        data = data.slice();
        data.unshift({
            id: '',
            text: _('select a species', true)
        });

        selector.select2({
            dropdownParent: $(options.modal_selector).find('.modal-content'),
            escapeMarkup: function escapeMarkup(a) {
                return a;
            },
            templateResult: function templateResult(data) {
                if ('is_primary' in data && (0, _protocol.is_primary)(data)) {
                    return '<span class="app-transect-species-primary">' + data.text + '</span>';
                }
                return data.text;
            },
            data: data
        });
    }

    this.modal = function (selector, pin_name) {
        var pin = form_data.getPin(pin_name);

        selector.data('name', pin_name);
        selector.find('.pinpoint-name').html('<div class="leaflet-number-marker">' + pin_name + '</div>');
        selector.find('form').html('<div class="modal-body"></div>');

        var header = selector.find('.modal-header');
        header.find('label').remove();
        if (options.enable_fix_location_checkbox) {
            header.prepend('<label class="pull-right"><input type="checkbox" /> ' + _('fix location', true) + '</label>');
            var checked = 'fix_location' in pin && pin.fix_location === true;
            header.find('input[type=checkbox]').prop('checked', checked);
        }

        var body = selector.find('.modal-body');
        var html = '';
        if (protocol.hasSampleAttrs()) {
            html += '<h4>' + _('attributes', true) + '</h4>';
            protocol.eachSampleAttr(function (attr, pk) {
                var input = '<label class="control-label col-sm-4">' + attr.name + '</label>';
                input += '<div class="col-sm-6">';

                var current_value = pin.attributes[pk] || '';
                if (attr.choices && attr.choices.length > 0) {
                    input += '<select data-sample-attr="' + pk + '" class="form-control">';
                    attr.choices.forEach(function (choice) {
                        var selected = choice[0] == current_value ? 'selected="selected"' : '';
                        input += '<option value="' + choice[0] + '" ' + selected + '>' + choice[1] + '</option>';
                    });
                    input += '</select>';
                } else {
                    input += render_input({
                        type: 'text',
                        class: 'form-control',
                        'data-sample-attr': pk,
                        value: current_value
                    });
                }
                input += '</div>';
                html += form_group(input);
            });
            body.append(html);
        }

        if (protocol.pinpoint_observation) {
            // all species are selectable.
            var selectable_species = get_selectable_species();

            // let the user choose species, subjects and supply a count.
            html = '<div class="form-group">' + form_group('<select class="form-control species-selector"></select>') + form_group('<select class="form-control subject-selector"><option disabled="disabled">Select species first</option></select>') + form_group(render_input({
                class: 'form-control',
                'min': 0,
                name: 'count',
                placeholder: 'count'
            })) + '</div>';

            body.append(html);
            if (selectable_species.length > 0) {
                render_species_select2(body.find('.species-selector'), selectable_species);
            }

            // update subject selector
            var species_selector = body.find('.species-selector');
            var subject_selector = body.find('.subject-selector');
            species_selector.on('change', function () {
                var group = $(this).select2('data')[0].group;
                if (group === undefined) {
                    return;
                }

                var subjects = [];
                protocol.eachSubject(function (name, pk) {
                    subjects.push({ id: pk, text: name });
                }, group.pk);

                subject_selector.empty().select2({
                    dropdownParent: $(options.modal_selector).find('.modal-content'),
                    data: subjects
                });
            });
            // initial render of subject dropdown
            species_selector.change();

            // set the initial values for this form:
            var observation = form_data.getObservation(pin_name);
            if (observation && observation.species && observation.subject) {
                species_selector.val(observation.species).trigger('change');
                subject_selector.val(observation.subject).trigger('change');
                body.find('[name="count"]').val(observation.count);
            }
        } else {
            html = '<table class="table app-transect-table">';
            protocol.eachGroup(function (group) {
                html += '<tr><th>' + group.name + '</th>';
                protocol.eachSubject(function (name) {
                    html += '<td>' + name + '</td>';
                }, group.pk);
                html += '</tr>';

                protocol.eachActiveSpecies(function (species) {
                    html += render_input_row(pin_name, species, group);
                }, group.pk);

                var selectable_species = get_selectable_species(group.pk);
                if (selectable_species.length > 0) {
                    html += render_secondary_selector(group);
                }
            });
            html += '</table>';
            body.append(html);

            protocol.eachGroup(function (group) {
                var selectable_species = get_selectable_species(group.pk);
                if (selectable_species.length == 0) {
                    return;
                }
                render_species_select2(body.find('.species-selector[data-group="' + group.pk + '"]'), selectable_species);
            });
        }
        selector.find('form').toggleClass('form-inline', protocol.pinpoint_observation).toggleClass('form-horizontal', !protocol.pinpoint_observation);
    };
}

exports.PinpointTable = PinpointTable;
exports.PinpointRenderer = PinpointRenderer;

/***/ }),
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fieldwork = undefined;

var _pinpoint = __webpack_require__(4);

var _pinpoint2 = _interopRequireDefault(_pinpoint);

var _pinpointController = __webpack_require__(29);

var _pinpointController2 = _interopRequireDefault(_pinpointController);

var _pinpointRenderer = __webpack_require__(6);

var _protocol = __webpack_require__(2);

__webpack_require__(31);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var fieldwork = {
    Protocol: _protocol.Protocol,
    PinpointController: _pinpointController2.default,
    Pinpoint: _pinpoint2.default,
    PinpointRenderer: _pinpointRenderer.PinpointRenderer,
    PinpointTable: _pinpointRenderer.PinpointTable,
    is_primary: _protocol.is_primary
};

exports.fieldwork = fieldwork;

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _extend = __webpack_require__(5);

var _extend2 = _interopRequireDefault(_extend);

var _pinpoint = __webpack_require__(4);

var _pinpoint2 = _interopRequireDefault(_pinpoint);

var _pinpointRenderer = __webpack_require__(6);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var PinpointController = function () {
    function PinpointController(map, pinpoint_data, options) {
        _classCallCheck(this, PinpointController);

        this.map = map;

        this.options = options = (0, _extend2.default)({
            output_selector: '[name=samples]',
            modal_selector: '#pinpoint_form',
            table_selector: '#observations',

            // if mapclick_create is disabled, new samples can only be created Using
            // the create_button.
            mapclick_create: true,
            // If this contains a selector, a click event will be attached
            // which creates a new pin without a latlng/marker.
            create_button_selector: '',

            // adds a checkbox to the modal to mark this pinpoint location
            // fixed to make it available in the next pinpoint sessions.
            // If the checkbox is checked,
            enable_fix_location_checkbox: false,
            // The default value for the state of the fix_location checkbox
            default_fix_location_state: true,

            // warn when trying to navigate away when the editor has unsaved changes
            warn_for_unsaved_changes: true
        }, options);

        this.modal = $(options.modal_selector);
        this.table = $(options.table_selector);

        try {
            var form_data = this.form_data = new _pinpoint2.default(pinpoint_data);
        } catch (e) {
            this.table.html('<h1>Error in protocol: <em>' + e + '</em></h1>');
        }

        this.renderer = new _pinpointRenderer.PinpointRenderer(this.form_data, options);
        this._ = this.form_data._;

        this.markers = {};
        this.editing_state = false;

        this.tableRenderer = new _pinpointRenderer.PinpointTable(form_data, options, this.table);

        var controller = this;
        if (options.mapclick_create) {
            map.on('click', function (e) {
                if (!controller.editing_state) {
                    // add marker and open modal
                    var pin = form_data.createPin(e.latlng);
                    if (options.enable_fix_location_checkbox) {
                        pin.fix_location = options.default_fix_location_state;
                    }

                    controller.addMapMarker(form_data.createMarker(pin));
                    controller.showEditor(pin.name);
                }
            });
        }
        if (options.create_button_selector) {
            $(options.create_button_selector).on('click', function () {
                var pin = form_data.createPin();
                controller.showEditor(pin.name);
            });
        }

        // add initial map markers.
        var bounds = L.latLngBounds();
        if (map.geojson_layer) {
            bounds.extend(map.geojson_layer.getBounds());
        }
        form_data.eachPin(function (pin) {
            if (pin.latlng) {
                var marker = controller.addMapMarker(form_data.createMarker(pin));
                bounds.extend(marker.getLatLng());
            }
        }, this);
        if (bounds.isValid()) {
            map.fitBounds(bounds.pad(0.2));
        }

        this.update();
        this.initModal();

        this.table.on('click', '[data-target]', function () {
            var pin_name = '' + $(this).parent().data('pin-name');

            switch ($(this).data('target')) {
                case 'move-marker':
                    var marker = controller.markers[pin_name];
                    alert(form_data._('click on map to choose new location'));
                    controller.editing_state = true;

                    map.once('click', function (e) {
                        L.DomEvent.preventDefault(e);

                        form_data.setLatLng(pin_name, e.latlng);
                        marker.setLatLng(e.latlng);
                        controller.update();
                        controller.editing_state = false;
                        controller.dirty = true;
                    });

                    break;
                case 'delete':
                    controller.dirty = true;
                    controller.removePin(pin_name);
                    break;
                default:
                    controller.showEditor(pin_name);
            }
        });

        controller.dirty = false;
        if (options.warn_for_unsaved_changes) {
            window.onbeforeunload = function () {
                if (controller.dirty) {
                    return true;
                }
            };
            // make sure the form submit button still works.
            $(options.output_selector).parents('form').find('input[type="submit"]').on('click', function () {
                window.onbeforeunload = null;
            });
        }
    }

    _createClass(PinpointController, [{
        key: 'initModal',
        value: function initModal() {
            var modal = this.modal;
            var form_data = this.form_data;
            var _ = form_data._;
            var renderer = this.renderer;
            var controller = this;
            var pinpoint_observation = form_data.protocol.pinpoint_observation;

            modal.on('shown.bs.modal', function () {
                $(this).find('input').first().focus();
            });
            modal.on('hidden.bs.modal', function () {
                controller.update();
            });

            if (!pinpoint_observation) {
                // listen for change on species-selector, of which might be multiple in the modal.
                modal.on('select2:close', '.species-selector', function () {
                    var pin_name = modal.data('name');
                    var species_pk = +$(this).val();

                    if (species_pk == '') {
                        // alert(_('You must select a species'));
                        return;
                    }
                    modal.find('.select2-hidden-accessible').select2('destroy');
                    controller.saveEditorData(true);
                    form_data.protocol.activateSpecies(species_pk);

                    // re-render modal.
                    renderer.modal(modal, pin_name);

                    // focus on firt input in newly added row:
                    modal.find('input[data-species="' + species_pk + '"]').first().focus();
                });
            }

            var modal_save = function modal_save() {
                if (pinpoint_observation && $(modal).find('.species-selector').val() == '') {
                    alert(_('you must select a species', true));
                    return;
                }

                controller.saveEditorData();
                modal.modal('hide');
            };

            // save button in modal
            modal.on('click', '[data-save]', modal_save);

            // submit form in modal on enter.
            modal.on('keypress', function (e) {
                if (e.which == 13) {
                    // enter
                    modal_save();
                    // prevent the form in the modal from submitting
                    e.preventDefault();
                }
            });

            // cancel button in modal
            modal.on('click', '[data-dismiss]', function () {
                var pin = form_data.getPin($(modal).data('name'));

                if ('delete_on_cancel' in pin) {
                    // remove pin without asking for permission
                    controller.removePin(pin.name, true);
                }
                controller.update();
                modal.modal('hide');
            });
        }
    }, {
        key: 'showEditor',
        value: function showEditor(pin_name) {
            this.renderer.modal(this.modal, pin_name);
            this.modal.modal({ backdrop: 'static', keyboard: false });
        }
    }, {
        key: 'addMapMarker',
        value: function addMapMarker(marker) {
            var controller = this;

            marker.addTo(this.map);
            marker.on('click', function markerclick(e) {
                controller.showEditor(e.target.feature.properties.name);

                // do not propagate click to map.
                L.DomEvent.stopPropagation(e);
            });

            this.markers[marker.feature.properties.name] = marker;
            return marker;
        }
    }, {
        key: 'removePin',
        value: function removePin(pin_name, no_ask_permission) {
            var _ = this.form_data._;
            if (!no_ask_permission && !confirm(_('are you sure you want to delete this observation?', true))) {
                return false;
            }

            if (this.markers[pin_name]) {
                this.markers[pin_name].removeFrom(this.map);
            }

            this.form_data.removePin(pin_name);
            this.update();
            return true;
        }
    }, {
        key: 'saveEditorData',
        value: function saveEditorData(preserve_delete_on_cancel) {
            preserve_delete_on_cancel = preserve_delete_on_cancel === true;
            var count_input_selector = 'input[type="number"]';

            var pin_name = this.modal.data('name');
            var form_data = this.form_data;
            var modal = this.modal;

            if (form_data.protocol.pinpoint_observation) {
                form_data.updateCount(pin_name, +$('.species-selector').val(), +$('.subject-selector').val(), modal.find(count_input_selector).val());
            } else {
                // sample attributes
                modal.find('[data-sample-attr]').each(function () {
                    var input = $(this);

                    form_data.updateAttribute(pin_name, +input.data('sample-attr'), input.val());
                });

                // observed counts
                modal.find(count_input_selector).each(function () {
                    var input = $(this);
                    form_data.updateCount(pin_name, +input.data('species'), +input.data('subject'), input.val());
                });
            }
            var pin = form_data.getPin(pin_name);

            if (this.options.enable_fix_location_checkbox) {
                pin.fix_location = modal.find('input[type=checkbox]').prop('checked');
            }
            if (!preserve_delete_on_cancel) {
                delete pin['delete_on_cancel'];

                // set dirty state, we saved something that should not be lost without confirmation
                this.dirty = true;
            }
        }
    }, {
        key: 'update',
        value: function update() {
            $(this.options.output_selector).val(this.form_data.serialize());

            var data = this.form_data.tableData();
            this.tableRenderer.render(data);
        }
    }]);

    return PinpointController;
}();

exports.default = PinpointController;

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = template;
// https://github.com/Leaflet/Leaflet/blob/master/src/core/Util.js

var templateRe = /\{ *([\w_-]+) *\}/g;

function template(str, data) {
    return str.replace(templateRe, function (str, key) {
        var value = data[key];

        if (value === undefined) {
            throw new Error('No value provided for variable ' + str);
        } else if (typeof value === 'function') {
            value = value(data);
        }
        return value;
    });
}

/***/ }),
/* 31 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })
/******/ ]);