/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = L;

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_leaflet__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_leaflet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_leaflet__);
/*
 * Prevent accidental scrolling on a map if the user only tries to
 * scroll the page.
 * amended from: https://gist.github.com/acdha/9143318
 */


var ScrollIntentMessage = __WEBPACK_IMPORTED_MODULE_0_leaflet___default.a.Control.extend({
    options: {
        position: 'bottomleft'
    },
    onAdd: function (map) {
        var container = __WEBPACK_IMPORTED_MODULE_0_leaflet___default.a.DomUtil.create('div', 'scroll-intent-message leaflet-control');
        var size = map.getSize();

        container.innerHTML = 'Klik op kaart voor interactie';
        container.style.left = ((size.x - 222) / 2) + 'px';
        container.style.bottom = '50px';

        container.style.fontSize = '20px';
        container.style.backgroundColor = 'white';
        container.style.border = '5px solid gray';
        container.style.borderRadius = '5px';
        container.style.padding = '4px 10px';

        // initially hidden
        container.style.display = 'none';
        return container;
    },
    hide: function () {
        this._container.style.display = 'none';
    },
    show: function () {
        this._container.style.display = 'block';
    }
});

function disableMapInteraction () {
    this.scrollWheelZoom.disable();
    this.touchZoom.disable();
}
function enableMapInteraction (e) {
    __WEBPACK_IMPORTED_MODULE_0_leaflet___default.a.DomEvent.preventDefault(e);
    this.scrollWheelZoom.enable();
    this.touchZoom.enable();

    this._scrollIntentMessage.hide();
}

function preventAccidentalScroll(map) {
    var control = new ScrollIntentMessage().addTo(map);
    disableMapInteraction.call(map);

    map.on('mouseover', function () {
        if (!map.scrollWheelZoom.enabled()) {
            control.show();
        }
    }, map);
    map.on('mouseout', function () {
        setTimeout(function () {
            control.hide();
        }, 1000);
    });

    map.on('click touch focus dragstart', enableMapInteraction, map);
    map.on('blur', disableMapInteraction, map);

    map._scrollIntentMessage = control;
}
__WEBPACK_IMPORTED_MODULE_0_leaflet___default.a.Map.include({
    preventAccidentalScroll: function () {
        preventAccidentalScroll(this);
    }
});
/* harmony default export */ __webpack_exports__["default"] = (preventAccidentalScroll);


/***/ })
/******/ ]);