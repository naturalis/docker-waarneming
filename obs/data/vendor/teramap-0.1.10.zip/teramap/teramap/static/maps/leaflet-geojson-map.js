import L from 'leaflet';

import leaflet_map from './leaflet-map.js';

import {numberIcon} from '../lib/leaflet-number-marker.js';

function layer_bounds(layer) {
    if (layer.getBounds) {
        return layer.getBounds();
    } else {
        return L.latLngBounds(layer.getLatLng(), layer.getLatLng());
    }
}

function default_geojson(data) {
    var layer = L.geoJson(data, {
        style: function(feature) {
            var style = {};
            if ('color' in feature.properties) {
                style['color'] = feature.properties.color;
            }
            return style;
        },
        pointToLayer: function (feature, latlng) {
            if ('circle_marker' in feature.properties){
                return L.circleMarker(latlng, {
                    radius: feature.properties.circle_marker
                });
            }
            var marker = L.marker(latlng);
            if ('number_marker' in feature.properties) {
                marker.setIcon(numberIcon(feature.properties.number_marker));
                return marker;
            }

            if ('color' in feature.properties && marker.setIcon) {
                var colorIcon = require('./leaflet-color-icon.js');

                marker.setIcon(colorIcon(feature.properties.color));
            }
            return marker;
        },
        onEachFeature: function (feature, layer) {
            var properties = feature.properties;
            if ('no_popup' in properties) {
                return;
            }

            if ('name' in properties || 'projects' in properties) {
                var html = '';
                if ('projects' in properties && properties.projects.length > 0) {
                    html += '<strong>Projecten</strong>';
                    html += '<ul>';
                    properties.projects.forEach(function (project) {
                        html += L.Util.template('<li><a href="{url}">{name}</a></li>', project);
                    });
                    html += '</ul>';
                } else {
                    if ('url' in properties) {
                        html = L.Util.template('<a href="{url}">{name}</a>', properties);
                    } else {
                        html = properties.name;
                    }
                }
                html += '<br />';
                if ('location_id' in properties) {
                    var focus_on_fmt = '<a href="javascript:focusOnFeature(\'location_id\', {location_id})">&gt; laat zien op de kaart</a>';
                    html += L.Util.template(focus_on_fmt, properties);
                }
                layer.bindPopup(html);
            }
        }
    });

    return layer;
}

function map_with_geojson(map_id, options, geojson_data) {
    var map = leaflet_map(map_id, options);

    if (geojson_data) {
        var layer = default_geojson(geojson_data).addTo(map);
        // TODO: use bindPopup here to defer creating the popup.

        window.zoomOut = function () {
            var bounds = layer.getBounds();
            if (bounds.isValid()) {
                map.fitBounds(bounds, {maxZoom: 16});
            }
        };
        window.zoomOut();

        window.focusOnFeature = function (key, value) {
            // focus on the feature or the features which have key=value in their properties.
            var bounds;
            layer.eachLayer(function (layer) {
                var properties = layer.feature.properties;
                if (key in properties && properties[key] == value) {
                    if (bounds) {
                        bounds.extend(layer_bounds(layer));
                    } else {
                        bounds = layer_bounds(layer);
                    }
                }
            });
            map.fitBounds(bounds, {maxZoom: 16});
        };

        map.geojson_layer = layer;
    }
    map.invalidateSize();
    return map;
}

export {default_geojson, map_with_geojson};
