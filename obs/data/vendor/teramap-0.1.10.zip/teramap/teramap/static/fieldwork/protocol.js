function is_primary(species) {
    return 'is_primary' in species ? species.is_primary : false;
}

function _active_species (protocol) {
    var active = [];
    var species = protocol.species;
    for (var i in species) {
        if (is_primary(species[i]) || species[i].is_active) {
            active.push(species[i]);
        }
    }
    // sort initially on is_primary, name:
    active.sort(function (a, b) {
        if (is_primary(a) && ! is_primary(b)) {
            return -1;
        }
        if (is_primary(b) && !is_primary(a)) {
            return 1;
        }
        return a.name > b.name;
    });

    return active.map(function (species) {
        return species.pk;
    });
}


class Protocol {
    /* Class to manage the a protocol.
     * Refer to ./README.md for documentation
     */
    constructor (protocol) {
        ['subjects', 'species', 'groups'].forEach(function (type) {
            if (Object.keys(protocol[type]).length === 0) {
                throw new Error('No ' + type + ' provided');
            }
        });

        this.subjects = protocol.subjects;
        this.species = protocol.species;
        this.groups = protocol.groups;

        this.pinpoint_target = protocol.pinpoint_target;
        this.pinpoint_observation = protocol.pinpoint_target == 'observation';

        this.sample_attrs = protocol.sample_attrs || {};

        this.active_species = _active_species(protocol);
    }

    activateSpecies (species_pk) {
        this.species[species_pk].is_active = true;
        if (this.active_species.indexOf(species_pk) === -1) {
            this.active_species.push(species_pk);
        }
    }

    eachSubject (fn, group_pk) {
        var subjects;
        if (group_pk !== undefined) {
            subjects = this.groups[group_pk].subjects;
        } else {
            subjects = Object.keys(this.subjects);
        }
        subjects.forEach(function (pk) {
            fn(this.subjects[pk], pk);
        }, this);
    }

    // iterate over subjects by unique name.
    eachSubjectName (fn) {
        var subjects = {};
        this.eachSubject(function (subject, pk) {
            if (!(subject in subjects)) {
                subjects[subject] = [];
            }
            subjects[subject].push(+pk);
        });

        for (var name in subjects) {
            fn(name, subjects[name]);
        }
    }

    _eachSpecies (callback, filter, context) {
        // low level eachSpecies, which takes custom filter method.
        for (var i in this.species) {
            if (filter && !filter(this.species[i])) {
                continue;
            }
            callback.call(context, this.species[i], this.species[i].pk);
        }
    }

    eachActiveSpecies (callback, group_pk) {
        var active_species = this.active_species;
        if (group_pk !== undefined) {
            var group_species = this.groups[group_pk].species;
            active_species = active_species.filter(function (pk) {
                return group_species.indexOf(pk) !== -1;
            });
        }

        active_species.forEach(function (species_pk) {
            callback(this.species[species_pk], species_pk);
        }, this);
    }

    // all species, except those active
    eachSelectableSpecies (callback, group_pk) {
        var group_species = false;
        if (group_pk !== undefined) {
            group_species = this.groups[group_pk].species;
        }

        this._eachSpecies(callback, function (species) {
            if (group_species && group_species.indexOf(species.pk) === -1) {
                return false;
            }
            return !(is_primary(species) || species.is_active);
        });
    }

    eachGroup (fn) {
        for (var pk in this.groups) {
            fn(this.groups[pk], pk);
        }
    }

    getGroupForSpecies (species) {
        // returns the group species belongs to.
        for (var pk in this.groups) {
            var group = this.groups[pk];
            if (group.species.indexOf(species.pk) !== -1) {
                return group;
            }
        }
    }

    selectSubjectForSpecies (subject_pks, species) {
        // from a list of subject pks, get the one relevant for this species.
        var ret;
        var group = this.getGroupForSpecies(species);
        group.subjects.forEach(function (subject) {
            if (subject_pks.indexOf(subject) !== -1) {
                ret = subject;
            }
        });
        return ret;
    }

    hasSampleAttrs () {
        return (
            !this.pinpoint_observation &&
            Object.keys(this.sample_attrs).length > 0
        );
    }

    eachSampleAttr (fn) {
        for (var pk in this.sample_attrs) {
            fn(this.sample_attrs[pk], pk);
        }
    }
}

export {is_primary, Protocol};
export default Protocol;
