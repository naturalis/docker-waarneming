/**
 * Created by folkert on 31/10/2017.
 */


export default function is_primary(species) {
    return 'is_primary' in species ? species.is_primary : false;
}
