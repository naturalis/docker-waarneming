import extend from '../lib/extend.js';
import template from '../lib/template.js';
import {is_primary} from './protocol.js';


function render_species_name (species, extra_classes) {
    var classNames = extra_classes || '';
    if (is_primary(species)) {
        classNames += ' app-transect-species-primary';
    }

    return template('<span class="{class}" title="{scientific_name}">{name}</span>', {
        class: classNames,
        scientific_name: species.scientific_name || '',
        name: species.name || '<em>' + species.scientific_name + '</em>'
    });
}

function form_group(contents) {
    return '<div class="form-group">' + contents + '</div>';
}

// renders an input, (type=number by default)
function render_input(attributes) {
    attributes = extend({type: 'number'}, attributes);

    var attrs = [];
    for (var name in attributes) {
        attrs.push(name + '="' + attributes[name] + '"');
    }

    return '<input ' + attrs.join(' ') + '/>';
}


class PinpointTable {

    constructor (form_data, options, selector) {
        this.form_data = form_data;
        this.options = options;
        this.selector = selector;
    }

    render (data) {
        var options = this.options;

        var edit_fmt = '<div class="leaflet-number-marker">{name}</div>&nbsp;&nbsp;' +
            '<span data-pin-name="{name}" class="btn-group btn-group-xs">' +
                '<span data-target="edit" class="btn btn-default"><i class="fa fa-edit"></i></span>' +
                (options.mapclick_create ? '<span data-target="move-marker" class="btn btn-default"><i class="fa fa-map-marker"></i></span>' : '') +
                '<span data-target="delete" class="btn btn-danger"><i class="fa fa-remove"></i></span>' +
            '</span>';

        var html = '<thead><tr>';
        data[0].forEach(function (header) {
            html += '<th>' + header + '</th>';
        });
        html += '</tr>';

        var prev_name;
        data.slice(1).forEach(function (row) {
            var name = row[0];
            if (prev_name === undefined || prev_name != name) {
                html += '<tr class="first"><td>' + template(edit_fmt, {
                    name: name
                });
            } else {
                html += '<tr><td>';
            }
            html += '</td>';
            html += '<td>' + render_species_name(row[1]) + '</td>';

            row.slice(2).forEach(function (column) {
                column = (column === undefined) ? '' : column;
                html += '<td>' + column + '</td>';
            });
            prev_name = name;
        });
        html += '</tbody>';

        this.selector.html(html);
    }
}

function PinpointRenderer (form_data, options) {
    var _ = form_data._;
    var protocol = form_data.protocol;

    // Render an input row for a species.
    function render_input_row(pin_name, species, group) {
        var row = '<tr><td>' + render_species_name(species, 'form-control-static text-right') + '</td>';

        protocol.eachSubject(function (name, subject_pk) {
            var value = form_data.observedCount(pin_name, species.pk, subject_pk);
            if (value === undefined) {
                value = '';
            }

            var input = render_input({
                'class': 'form-control app-transect-subject-input center-block',
                'data-species': species.pk,
                'data-subject': subject_pk,
                'min': 0,
                'value': value
            });
            row += '<td>' + input + '</td>';
        }, group.pk);
        row += '</tr>';
        return row;
    }

    function render_secondary_selector(group) {
        var subject_count = 0;
        protocol.eachSubject(function () { subject_count++; }, group.pk);

        var html = '<tr>' +
            '<td><select class="form-control species-selector" data-group="' + group.pk + '"></select></td>' +
            '<td colspan="' + subject_count + '">' +
            '</td>' +
            '</tr>';

        return html;
    }

    function get_selectable_species(group_pk) {
        var species = [];
        function species_to_select2_dict (item) {
            species.push({
                id: item.pk,
                text: item.name || '<em>' + item.scientific_name + '</em>',
                is_primary: is_primary(item),
                group: protocol.getGroupForSpecies(item)
            });
        }

        // in case of pinpoint_observation, also include active species.
        if (protocol.pinpoint_observation) {
            protocol.eachActiveSpecies(species_to_select2_dict, group_pk);
        }

        protocol.eachSelectableSpecies(species_to_select2_dict, group_pk);
        return species;
    }

    function render_species_select2(selector, data) {
        data = data.slice();
        data.unshift({
            id: '',
            text: _('select a species', true)
        });

        selector.select2({
            dropdownParent: $(options.modal_selector).find('.modal-content'),
            escapeMarkup: function (a) { return a; },
            templateResult: function (data) {
                if ('is_primary' in data && is_primary(data)) {
                    return '<span class="app-transect-species-primary">' + data.text + '</span>';
                }
                return data.text;
            },
            data: data
        });
    }

    this.modal = function(selector, pin_name) {
        var pin = form_data.getPin(pin_name);

        selector.data('name', pin_name);
        selector.find('.pinpoint-name').html('<div class="leaflet-number-marker">' + pin_name + '</div>');
        selector.find('form').html('<div class="modal-body"></div>');

        var header = selector.find('.modal-header');
        header.find('label').remove();
        if (options.enable_fix_location_checkbox) {
            header.prepend(
                '<label class="pull-right"><input type="checkbox" /> ' +
                _('fix location', true) +
                '</label>'
            );
            var checked = ('fix_location' in pin && pin.fix_location === true);
            header.find('input[type=checkbox]').prop('checked', checked);
        }

        var body = selector.find('.modal-body');
        var html = '';
        if (protocol.hasSampleAttrs()) {
            html += '<h4>' + _('attributes', true) + '</h4>';
            protocol.eachSampleAttr(function (attr, pk) {
                var input = '<label class="control-label col-sm-4">' + attr.name + '</label>';
                input += '<div class="col-sm-6">';

                var current_value = pin.attributes[pk] || '';
                if (attr.choices && attr.choices.length > 0) {
                    input += '<select data-sample-attr="' + pk + '" class="form-control">';
                    attr.choices.forEach(function (choice) {
                        var selected = (choice[0] == current_value) ? 'selected="selected"' : '';
                        input += '<option value="' + choice[0] + '" ' + selected + '>' + choice[1] + '</option>';
                    });
                    input += '</select>';
                } else {
                    input += render_input({
                        type: 'text',
                        class: 'form-control',
                        'data-sample-attr': pk,
                        value: current_value
                    });
                }
                input += '</div>';
                html += form_group(input);
            });
            body.append(html);
        }

        if (protocol.pinpoint_observation) {
            // all species are selectable.
            var selectable_species = get_selectable_species();

            // let the user choose species, subjects and supply a count.
            html = '<div class="form-group">' +
                form_group('<select class="form-control species-selector"></select>') +
                form_group('<select class="form-control subject-selector"><option disabled="disabled">Select species first</option></select>') +
                form_group(render_input({
                    class: 'form-control',
                    'min': 0,
                    name: 'count',
                    placeholder: 'count'
                })) + '</div>';

            body.append(html);
            if (selectable_species.length > 0) {
                render_species_select2(body.find('.species-selector'), selectable_species);
            }

            // update subject selector
            var species_selector = body.find('.species-selector');
            var subject_selector = body.find('.subject-selector');
            species_selector.on('change', function () {
                var group = $(this).select2('data')[0].group;
                if (group === undefined) {
                    return;
                }

                var subjects = [];
                protocol.eachSubject(function (name, pk) {
                    subjects.push({id: pk, text: name});
                }, group.pk);

                subject_selector.empty().select2({
                    dropdownParent: $(options.modal_selector).find('.modal-content'),
                    data: subjects
                });
            });
            // initial render of subject dropdown
            species_selector.change();

            // set the initial values for this form:
            var observation = form_data.getObservation(pin_name);
            if (observation && observation.species && observation.subject) {
                species_selector.val(observation.species).trigger('change');
                subject_selector.val(observation.subject).trigger('change');
                body.find('[name="count"]').val(observation.count);
            }
        } else {
            html = '<table class="table app-transect-table">';
            protocol.eachGroup(function(group) {
                html += '<tr><th>' + group.name + '</th>';
                protocol.eachSubject(function (name) {
                    html += '<td>' + name + '</td>';
                }, group.pk);
                html += '</tr>';

                protocol.eachActiveSpecies(function (species) {
                    html += render_input_row(pin_name, species, group);
                }, group.pk);

                var selectable_species = get_selectable_species(group.pk);
                if (selectable_species.length > 0) {
                    html += render_secondary_selector(group);
                }
            });
            html += '</table>';
            body.append(html);

            protocol.eachGroup(function (group) {
                var selectable_species = get_selectable_species(group.pk);
                if (selectable_species.length == 0) {
                    return;
                }
                render_species_select2(
                    body.find('.species-selector[data-group="' + group.pk + '"]'),
                    selectable_species
                );
            });
        }
        selector.find('form')
            .toggleClass('form-inline', protocol.pinpoint_observation)
            .toggleClass('form-horizontal', !protocol.pinpoint_observation);
    };
}

export {PinpointTable, PinpointRenderer};
