from django import template

from .. import __version__

register = template.Library()

@register.simple_tag
def teramap_version():
    return __version__
