import itertools
import json

from django.conf import settings
from django.urls import reverse
from django.utils.safestring import mark_safe

from .utils import Accessor, attr_or_key, json_serial, round_geom

# Assume 1 degree = 115 km = 115000 m, simplify to 25m
DEFAULT_SIMPLIFY = getattr(settings, 'GEOJSON_DEFAULT_SIMPLIFY', 25 / 115000)


class FeatureBase(object):
    def __len__(self):
        return len(self.features)

    def len(self):
        # length function to use in templates
        return self.__len__()

    def union(self, other):
        return FeatureCollection(itertools.chain(self.features, other.features))

    # support adding two Features/FeatureCollections:
    # geojson = geojson_a + geojson_b
    # geojson += a
    __add__ = union
    __iadd__ = union


class FeatureCollection(FeatureBase):
    def __init__(self, features):
        self.features = list(features)

    def to_geojson(self):
        return {
            'type': "FeatureCollection",
            'features': [
                feature.to_geojson() if isinstance(feature, Feature) else feature
                for feature in self.features
            ]
        }

    def to_geojson_str(self, indent=None):
        return json.dumps(self.to_geojson(), indent=indent, default=json_serial)

    def __str__(self):
        return mark_safe(str(self.to_geojson_str()))


class Feature(FeatureBase):
    @property
    def features(self):
        return (self,)

    def to_geojson(self):
        return {
            'type': 'Feature',
            'properties': self.properties,
            'geometry': {
                "type": self.geom_type,
                "coordinates": self.coords
            }
        }


class Point(Feature):
    geom_type = 'Point'

    def __init__(self, coords, properties=None):
        self.coords = coords
        self.properties = properties or {}


class LineString(Point):
    geom_type = 'LineString'


class TransformToPoint(object):
    '''
    Mixin to convert non-point geometries to a point.

    Useful to present lots of polygons as markers to reduce page load time.
    '''
    def geometry(self, obj):
        geom = super(TransformToPoint, self).geometry(obj)

        if geom.geom_typeid > 0:
            geom = geom.centroid
        return geom


class GeoJSON(FeatureCollection):
    """
    Transform a list of Models to geojson with properties according to specification
    """
    properties = {
        'id': 'pk'
    }
    geom_field = 'geom'
    precision = 6
    simplify = DEFAULT_SIMPLIFY

    def __init__(self, data, extra_properties=None):
        self.data = data or []

        if extra_properties is not None:
            self.properties = self.properties.copy()
            self.properties.update(extra_properties)

    def get_properties(self, obj):
        properties = {}

        for key, lookup in self.properties.items():
            if isinstance(lookup, bool):
                properties[key] = lookup
            elif callable(lookup):
                properties[key] = lookup(obj)
            else:
                properties[key] = Accessor(lookup).resolve(obj)

        return properties

    def geometry(self, obj):
        """
        Return the geometry simplified according to the current simplification
        settings.
        """
        geom = Accessor(self.geom_field).resolve(obj)
        return geom.simplify(self.simplify, preserve_topology=True)

    def feature(self, obj):
        try:
            geom = self.geometry(obj)
        except AttributeError:
            return None

        return {
            'type': 'Feature',
            'properties': self.get_properties(obj),
            'geometry': {
                'type': geom.geom_type,
                'coordinates': round_geom(geom.coords, self.precision)
            }
        }

    @property
    def features(self):
        """
        Return the GeoJSON representation of the list of locations.
        """
        if not hasattr(self, '_features'):
            self._features = []
            for location in self.data:
                feature = self.feature(location)
                if feature:
                    self._features.append(feature)

        return self._features

    def url(self, obj):
        return reverse(self.url_name, kwargs={'pk': attr_or_key(obj, 'pk')})
