# Teramap

Shared mapping functionality for Zostera projects.

The basic idea is to define as much properties of the geometries in the [GeoJSON] string. The JavaScript code used to render the json on a [Leaflet] map can then be fairly standard throughout the projects and applications.

**Installation**

As Teramap lives in a private bitbucket repository, and is not published on pypi, requiring it is a bit more complicated.

```
pip install git+ssh://git@bitbucket.org/zostera/teramap.git@v0.0.1#egg=teramap
```

Or in a `requirements.txt`-like file:
```
git+ssh://git@bitbucket.org/zostera/teramap.git@v0.0.1#egg=teramap
```

Make sure to always pin to a specific version (by appending a tag name i.e. `@v0.0.1`), as this is not yet cristalized and development will introduce breaking changes.

## Building JavaScript bundles.

`webpack` is used to build the bundles in `teramap/static/teramap/`.

You can install it an its dependencies using `npm install`.
- Running `npm run bundle` will recreate the bundles.
- Running `npm run watch` will watch the source JavaScript files for changes and rebuild the bundles if required.

**API**

- python object `teramap.GeoJSON`
- python mixin `teramap.TransformToPoint`
- python view `teramap.GeoJSONView`
- JavaScript `teramap(id, options, geojson)`
- JavaScript `teramap.fieldwork.Pinpoint(data)`
- JavaScript `teramap.fieldwork.PinpointRenderer(pinpoint)`
-
## python object `teramap.GeoJSON`

Wrapper for objects with geometries providing conversion to a [GeoJSON] string.

Geometries will will be [simplified](https://docs.djangoproject.com/en/1.11/ref/contrib/gis/geos/#django.contrib.gis.geos.GEOSGeometry.simplify) to the value specified in `GEOJSON_DEFAULT_SIMPLIFY`, which defaults to `25 / 115000`.

Instances of `teramap.GeoJSON` can be added together to merge them.
This allows one to pass one `geojson` context variable to the template.
The type of features doesn't matter.
```python
geojson = LocationGeoJSON(Location.objects.all())
geojson += RegionGeoJSON(Region.objects.all())
```

### attribute `properties`
Defines the contents of each feature in the generated GeoJSON, as key-value pairs.
Values can be:

- **bool**: Will include the value `key: value` in the properties.
- **callable**: Will include the value `key: value(item)` in the properties. The `item` argument will be the model for the current feature.
- **str**: Accessor, dotted path, allows following foreign key relations.
   Example: `user.first_name` will look for the attribute `user` on the model and return the value of it's `first_name` attribute.
    Default value: `{'id': 'pk'}` will include the primary key.

### attribute `geom_field`

Name of the geometry field, defaults to `geom`.

### attribute `precision`

Number of digits to round the coordinates too.

### attribute `simplify`

Tolerance for geometry simplification, defaults to GEOJSON_DEFAULT_SIMPLIFY

### attribute `url_name`

When a url to the object is required in properties, you can use the `url` method to generate it.
```python
class GeoJSON(teramap.GeoJSON):
    properties = {'url': self.url}
    url_name = 'location_detail'
```
will result in a call to `django.urls.reverse(url_name, kwargs={'pk': obj.pk})`.


### method `to_geojson_str(indent=None)`

Returns a string representation of the [GeoJSON] object. Optional `indent` argument allows formatting the output to be more readable (passed on to [json.dump()](https://docs.python.org/2/library/json.html#json.dump)).

### Example

This example will add both the model fields `id` and `name` to the `properties` map of the generated geojson.
```python
class GeoJSON(teramap.GeoJSON):
    properties = {
        'id': 'id',
        'name': 'name'
    }

geojson = GeoJSON(Location.objects.all())

>>> # returns a mark_safe()ed string containing the GeoJSON
>>> str(geojson)
'{"type": "FeatureCollection", "features": [{"geometry": {"type": "Point", "coordinates": [4.0, 52.0]}, "type": "Feature", "properties": {"id": 1, "name": "Point"}}, {"geometry": {"type": "Point", "coordinates": [4.0, 54.0]}, "type": "Feature", "properties": {"id": 2, "name": "Point 2"}}]}'

>>> geojson.to_geojson_str(2)
'{
  "type": "FeatureCollection",
  "features": [{
      "geometry": {
        "type": "Point",
        "coordinates": [4.0, 52.0]
      },
      "type": "Feature",
      "properties": {
        "id": 1,
        "name": "Point 1"
      }
    },
    {
      "geometry": {
        "type": "Point",
        "coordinates": [4.0, 54.0]
      },
      "type": "Feature",
      "properties": {
        "id": 2,
        "name": "Point 2"
      }
    }
  ]
}'
```

## python mixin `teramap.TransformToPoint`

When dealing with large amounts polygons, it often doesn't make sense to display them all as polygons.

```python
class GeoJSON(TransformToPoint, teramap.GeoJSON):
    pass
```

Adding the `TransformToPoint` mixin will convert all non-point geometries to their centroids.


## python view `teramap.GeoJSONView`

View that enables `django.views.generic.ListView` to emit [GeoJSON].

```python
class View(teramap.GeoJSONView, ListView):
    GeoJSONClass = GeoJSON
    model = Location
```

## JavaScript prerequisites

Before you can use the teramap, you have to make sure you include both `teramap.js` and `teramap.css` assets into your template. It is also assumed that leaflet is loaded, make sure that's done before loading teramap:

```HTML
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.2.0/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.2.0/dist/leaflet.js"></script>

<script src="{% static "teramap/teramap.js" %}"></script>
<link rel="stylesheet" href="{% static "teramap/teramap.css" %}" />
```

## JavaScript `teramap(id, options, geojson)`

Create's a Leaflet map in element with `id` `#<id>` using `options` explained later. If `geojson` is an object, it is assumed to be geojson and added using [L.geoJSON](http://leafletjs.com/reference-1.2.0.html#geojson).

### options for `teramap()`

- `fullscreenControl`: if `true`, a [Leaflet.fullscreen](https://github.com/Leaflet/Leaflet.fullscreen) control is added to the map.
- `preventAccidentalScroll`: if `true`, interacting with the map requires explicit intent first i.e. clicking the map container.
- `callback`: if type is function, it's called after creating the map with the map as argument.
- `baseLayers`: base layer to use for the map, (instance of [L.TileLayer](http://leafletjs.com/reference-1.2.0.html#tilelayer), defaults to openstreetmap, or a mapping of layer names and `L.TileLayer` instances.
- `overlays`: mapping of overlay layer names. If at least one is in the object, a [L.Control.Layers](http://leafletjs.com/reference-1.2.0.html#control-layers) is added with this item as second argument.
- `center`: initial map center, defaults to `[51, 4]`
- `zoom`: initial map zoom, defeults to `6`.


## JavaScript `teramap.fieldwork.Pinpoint(data)`

## JavaScript `teramap.fieldwork.PinpointRenderer(pinpoint)`



[GeoJSON]: http://geojson.org/
[Leaflet]: http://leafletjs.com/
