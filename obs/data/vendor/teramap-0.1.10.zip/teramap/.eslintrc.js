module.exports = {
    "extends": "eslint:recommended",
    "env": {
        "browser": true,
        "phantomjs": true
    },
    "globals": {
        "module": true,
        "define": true,
        "require": true,

        "chai": true,

        "L": true,
        "$": true,

        "teramap": true,
    },
    "parserOptions": {
        "ecmaVersion": 6,
        "sourceType": "module"
    },
    "rules": {
        "indent": [
            "error",
            4
        ],
        "linebreak-style": [
            "error",
            "unix"
        ],
        "quotes": [
            "error",
            "single"
        ],
        "semi": [
            "error",
            "always"
        ]
    }
};
