var path = require('path');
var webpack = require('webpack');

var ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
    context: __dirname,
    target: 'web',

    entry: {
        maps: './teramap/static/maps.js',
        fieldwork: './teramap/static/fieldwork.js',
        teramap: './teramap/static/index.js'
    },

    externals: {
        '$': 'jQuery',
        'leaflet': 'L'
    },
    // devtool: 'cheap-source-map',
    module: {
        rules: [
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: 'css-loader'
                })
            },
            {
                test: /\.(png|gif|jpg)$/,
                loader: 'url-loader'
            },
            {
                test: /\.js$/,
                loader: 'babel-loader',
                exclude: '/node_modules/',
                query: {
                    presets: ['es2015'],
                }
            }
        ],
        loaders: [
            { test: /\.css$/, loader: 'style-loader!css-loader' },
        ],
    },

    plugins: [
        // new (require('webpack-bundle-analyzer').BundleAnalyzerPlugin)(),
        // new (require('uglifyjs-webpack-plugin'))(),
        // save stylesheets to separate files
        new ExtractTextPlugin('[name].css'),
    ],

    output: {
        path: path.resolve('./teramap/static/teramap/'),
        filename: '[name].js',
        library: 'teramap',
        // libraryTarget: 'window'
    }
}
